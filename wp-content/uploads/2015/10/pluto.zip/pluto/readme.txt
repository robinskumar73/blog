Please see docs folder for complete documentation.

License numbers for included plugins:

UserPro: 0d9266ab-4233-42ee-b48b-5fc5bfb8ee5f
UserPro Messages: 07410c19-487f-4b42-a620-244f630599a2